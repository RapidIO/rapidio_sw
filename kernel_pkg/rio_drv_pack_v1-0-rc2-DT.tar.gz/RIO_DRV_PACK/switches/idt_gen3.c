/*
 * IDT RXS Gen.3 Serial RapidIO switch family support
 *
 * Copyright 2016 Integrated Device Technology, Inc.
 * Alexandre Bounine <alexandre.bounine@idt.com>
 *
 * This program is free software; you can redistribute  it and/or modify it
 * under  the terms of  the GNU General  Public License as published by the
 * Free Software Foundation;  either version 2 of the  License, or (at your
 * option) any later version.
 */

#include <linux/stat.h>
#include <linux/module.h>
#include "../include/rio.h"
#include "../include/rio_drv.h"
#include "../include/rio_ids.h"
#include "../include/rio_regs.h"
#include <linux/delay.h>

#include <asm/page.h>
#include "../rio.h"

#define IDT_DISCARD_ROUTE	0x300

#define RIO_BC_L2_Gn_ENTRYx_CSR(n, x)	(0x31000 + (n)*0x400 + (x)*0x4)
#define RIO_BC_RT_CTL	0x5020	/* RapidIO LP-Serial Broadcast Routing Table Control CSR */
#define RIO_SPx_L2_Gn_ENTRYy_CSR(x, n, y)	(0x51000 + (x)*0x2000 + (n)*0x400 + (y)*0x4)

static int
idtg3_route_add_entry(struct rio_mport *mport, u16 destid, u8 hopcount,
		       u16 table, u16 route_destid, u8 route_port)
{
	u32 rval;
	u32 entry = route_port;
	int err = 0;

	pr_debug("RIO: %s p=0x%x %x -> %x\n", __func__, table, route_destid, entry);

	if (route_destid > 0xFF)
		return -EINVAL;

	if (route_port == RIO_INVALID_ROUTE)
		entry = IDT_DISCARD_ROUTE;

	if (table == RIO_GLOBAL_TABLE) {
		/* Use broadcast register to update all per-port tables */
		err = rio_mport_write_config_32(mport, destid, hopcount,
				RIO_BC_L2_Gn_ENTRYx_CSR(0, route_destid),
				entry);
		//udelay(1);
		return err;
	}

	/*
	 * Verify that specified port/table number is valid
	 */
	err = rio_mport_read_config_32(mport, destid, hopcount,
				       RIO_SWP_INFO_CAR, &rval);
	if (err)
		return err;

	if (table >= RIO_GET_TOTAL_PORTS(rval))
		return -EINVAL;

	err = rio_mport_write_config_32(mport, destid, hopcount,
			RIO_SPx_L2_Gn_ENTRYy_CSR(table, 0, route_destid),
			entry);
	//udelay(1);
	return err;
}

static int
idtg3_route_get_entry(struct rio_mport *mport, u16 destid, u8 hopcount,
		       u16 table, u16 route_destid, u8 *route_port)
{
	u32 rval;
	int err;

	if (route_destid > 0xFF)
		return -EINVAL;

	err = rio_mport_read_config_32(mport, destid, hopcount,
				       RIO_SWP_INFO_CAR, &rval);
	if (err)
		return err;

	/*
	 * This switch device does not have the dedicated global routing table.
	 * It is substituted by reading routing table of the ingress port of
	 * maintenance read requests.
	 */
	if (table == RIO_GLOBAL_TABLE)
		table = RIO_GET_PORT_NUM(rval);
	else if (table >= RIO_GET_TOTAL_PORTS(rval))
		return -EINVAL;

	err = rio_mport_read_config_32(mport, destid, hopcount,
			RIO_SPx_L2_Gn_ENTRYy_CSR(table, 0, route_destid),
			&rval);
	if (err)
		return err;

	//pr_debug("RIO: %s %x -> %x\n", __func__, route_destid, rval);

	if (IDT_DISCARD_ROUTE == rval)
		*route_port = RIO_INVALID_ROUTE;
	else
		*route_port = (u8)rval;

	return 0;
}

static int
idtg3_route_clr_table(struct rio_mport *mport, u16 destid, u8 hopcount,
		       u16 table)
{
	u32 i;
	u32 rval;
	int err;

	if (table == RIO_GLOBAL_TABLE) {
		for (i = 0; i <= 0xff; i++) {
			err = rio_mport_write_config_32(mport, destid, hopcount,
						RIO_BC_L2_Gn_ENTRYx_CSR(0, i),
						IDT_DISCARD_ROUTE);
			if (err)
				break;
		}

		return err;
	}

	err = rio_mport_read_config_32(mport, destid, hopcount,
				       RIO_SWP_INFO_CAR, &rval);
	if (err)
		return err;

	if (table >= RIO_GET_TOTAL_PORTS(rval))
		return -EINVAL;

	for (i = 0; i <= 0xff; i++) {
		err = rio_mport_write_config_32(mport, destid, hopcount,
					RIO_SPx_L2_Gn_ENTRYy_CSR(table, 0, i),
					IDT_DISCARD_ROUTE);
		if (err)
			break;
	}

	return err;
}


#if (0)
static int
idtg3_set_domain(struct rio_mport *mport, u16 destid, u8 hopcount,
		       u8 sw_domain)
{
	return 0;
}

static int
idtg3_get_domain(struct rio_mport *mport, u16 destid, u8 hopcount,
		       u8 *sw_domain)
{
	return 0;
}
#endif

#if (0)
static int
idtg3_em_init(struct rio_dev *rdev)
{
	/*
	 * This routine performs device-specific initialization only.
	 * All standard EM configuration should be performed at upper level.
	 */

	pr_debug("RIO: %s [%d:%d]\n", __func__, rdev->destid, rdev->hopcount);


	/* set TVAL = ~50us */
	rio_write_config_32(rdev,
		rdev->phys_efptr + RIO_PORT_LINKTO_CTL_CSR, 0x8e << 8);
	return 0;
}

static int
idtg3_em_handler(struct rio_dev *rdev, u8 portnum)
{
	return 0;
}

static ssize_t
idtg2_show_errlog(struct device *dev, struct device_attribute *attr, char *buf)
{
	struct rio_dev *rdev = to_rio_dev(dev);
	ssize_t len = 0;
	u32 regval;

	while (!rio_read_config_32(rdev, IDT_ERR_RD, &regval)) {
		if (!regval)    /* 0 = end of log */
			break;
		len += snprintf(buf + len, PAGE_SIZE - len,
					"%08x\n", regval);
		if (len >= (PAGE_SIZE - 10))
			break;
	}

	return len;
}

static DEVICE_ATTR(errlog, S_IRUGO, idtg2_show_errlog, NULL);

static int idtg3_sysfs(struct rio_dev *rdev, bool create)
{
	struct device *dev = &rdev->dev;
	int err = 0;
	if (create) {
		/* Initialize sysfs entries */
		err = device_create_file(dev, &dev_attr_errlog);
		if (err)
			dev_err(dev, "Unable create sysfs errlog file\n");
	} else
		device_remove_file(dev, &dev_attr_errlog);
	return err;
}
#endif

static struct rio_switch_ops idtg3_switch_ops = {
	.owner = THIS_MODULE,
	.add_entry = idtg3_route_add_entry,
	.get_entry = idtg3_route_get_entry,
	.clr_table = idtg3_route_clr_table,
	.set_domain = NULL, //idtg3_set_domain,
	.get_domain = NULL, //idtg3_get_domain,
	.em_init = NULL, //idtg3_em_init,
	.em_handle = NULL, //idtg3_em_handler,
};

static int idtg3_probe(struct rio_dev *rdev, const struct rio_device_id *id)
{
	pr_debug("RIO: %s for %s\n", __func__, rio_name(rdev));

	spin_lock(&rdev->rswitch->lock);

	if (rdev->rswitch->ops) {
		spin_unlock(&rdev->rswitch->lock);
		return -EINVAL;
	}

//	pr_debug("RIO: %s mark %s as Gen3 device\n", __func__, rio_name(rdev));
//	rdev->gen3 = true;
	rdev->rswitch->ops = &idtg3_switch_ops;

	if (rdev->do_enum) {
		/* Force flat routing table */
		rio_write_config_32(rdev, RIO_BC_RT_CTL, 0);
	}

	spin_unlock(&rdev->rswitch->lock);

	/* Create device-specific sysfs attributes */
	//idtg3_sysfs(rdev, true);

	return 0;
}

static void idtg3_remove(struct rio_dev *rdev)
{
	pr_debug("RIO: %s for %s\n", __func__, rio_name(rdev));
	spin_lock(&rdev->rswitch->lock);
	if (rdev->rswitch->ops != &idtg3_switch_ops) {
		spin_unlock(&rdev->rswitch->lock);
		return;
	}
	rdev->rswitch->ops = NULL;

	/* Remove device-specific sysfs attributes */
	//idtg3_sysfs(rdev, false);

	spin_unlock(&rdev->rswitch->lock);
}

static struct rio_device_id idtg3_id_table[] = {
	{RIO_DEVICE(RIO_DID_IDTRXS1632, RIO_VID_IDT)},
	{RIO_DEVICE(RIO_DID_IDTRXS2448, RIO_VID_IDT)},
	{ 0, }	/* terminate list */
};

static struct rio_driver idtg3_driver = {
	.name = "idt_gen3",
	.id_table = idtg3_id_table,
	.probe = idtg3_probe,
	.remove = idtg3_remove,
};

static int __init idtg3_init(void)
{
	return rio_register_driver(&idtg3_driver);
}

static void __exit idtg3_exit(void)
{
	pr_debug("RIO: %s\n", __func__);
	rio_unregister_driver(&idtg3_driver);
	pr_debug("RIO: %s done\n", __func__);
}

device_initcall(idtg3_init);
module_exit(idtg3_exit);

MODULE_DESCRIPTION("IDT RXS Gen.3 Serial RapidIO switch family driver");
MODULE_AUTHOR("Integrated Device Technology, Inc.");
MODULE_LICENSE("GPL");
