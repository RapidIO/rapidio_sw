#!/bin/bash

SOURCE_PATH="/opt/rapidio/driver"

PRINTHELP=0

if [ "$#" -lt 6 ]; then
	echo $'\ndriver.sh requires 6 parameters.\n'
	PRINTHELP=1
fi

if [ $PRINTHELP = 1 ] ; then
    echo "install.sh <NODE1> <NODE2> <NODE3> <NODE4> <driver.zip> <group>"
    echo "<NODE1> Name of master, enumerating node"
    echo "<NODE2> Name of slave node connected to Switch Port 2"
    echo "<NODE3> Name of slave node connected to Switch Port 3"
    echo "<NODE4> Name of slave node connected to Switch Port 4"
    echo "<driver>Name of driver zip file to be installed"
    echo "<group> Unix file ownership group which should have access to"
    echo "        the RapidIO software"
    exit
fi

MASTER=$1
SLAVES=( )
ALLNODES=( $1 )
NODE2=""
NODE3=""
NODE4=""

## Put nodes into array in reverse order
## otherwise, the node running the script 
## would be the first node restarted...
if [ $1 != 'none' ]; then
	ALLNODES[3]=$1
fi

if [ $2 != 'none' ]; then
	ALLNODES[2]=$2
fi

if [ $3 != 'none' ]; then
	ALLNODES[1]=$3
fi

if [ $4 != 'none' ]; then
	ALLNODES[0]=$4
fi

DRIVER=$5
GRP=$6

for i in "${ALLNODES[@]}"
do
	ping -c 1 $i > /dev/null
	if [ $? -ne 0 ]; then
		echo $i " Not accessible, aborting..."
		exit
	else
		echo $i "accessible."
	fi
done

echo "Beginning installation..."

for host in  "${ALLNODES[@]}"; do
  [ "$host" = 'none' ] && continue;
  echo $host ":Copying files..."
  cat $DRIVER | \
  ssh -C root@"$host" "rm -rf $SOURCE_PATH; mkdir $SOURCE_PATH; pushd $SOURCE_PATH &>/dev/null; tar -zxvf -; popd &>/dev/null; chown -R root.$GRP $SOURCE_PATH"
done

for host in  "${ALLNODES[@]}"; do
  [ "$host" = 'none' ] && continue;
  echo $host ": Building files and installing..."
  ssh root@"$host" "cd $SOURCE_PATH/RIO_DRV_PACK;make clean; make all; make  install"
done

echo "Installion complete."
